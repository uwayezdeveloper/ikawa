<?php

namespace App\Models;

use App\Core\Model;
use App\Core\Database;

class Account extends Model
{
    protected string $table = 'accounts';

    /**
     * Get all accounts with related data
     */
    public function getAll(): array
    {
        $sql = "SELECT a.*, 
                lt.name as location_type_name,
                l.name as location_name,
                pm.name as payment_mode_name
                FROM {$this->table} a
                LEFT JOIN location_types lt ON a.location_type_id = lt.id
                LEFT JOIN locations l ON a.location_id = l.id
                LEFT JOIN payment_modes pm ON a.payment_mode_id = pm.id
                ORDER BY a.account_name ASC";
        return Database::fetchAll($sql);
    }

    /**
     * Get active accounts
     */
    public function getActive(): array
    {
        $sql = "SELECT a.*, 
                lt.name as location_type_name,
                l.name as location_name,
                pm.name as payment_mode_name
                FROM {$this->table} a
                LEFT JOIN location_types lt ON a.location_type_id = lt.id
                LEFT JOIN locations l ON a.location_id = l.id
                LEFT JOIN payment_modes pm ON a.payment_mode_id = pm.id
                WHERE a.status = 'active'
                ORDER BY a.account_name ASC";
        return Database::fetchAll($sql);
    }

    /**
     * Find account by ID with related data
     */
    public function findById(int $id): ?array
    {
        $sql = "SELECT a.*, 
                lt.name as location_type_name,
                l.name as location_name,
                pm.name as payment_mode_name
                FROM {$this->table} a
                LEFT JOIN location_types lt ON a.location_type_id = lt.id
                LEFT JOIN locations l ON a.location_id = l.id
                LEFT JOIN payment_modes pm ON a.payment_mode_id = pm.id
                WHERE a.id = :id";
        return Database::fetch($sql, ['id' => $id]);
    }

    /**
     * Check if account exists for location and payment mode
     */
    public function accountExists(int $locationId, int $paymentModeId, ?string $accountNumber = null, ?int $excludeId = null): bool
    {
        $sql = "SELECT COUNT(*) as count FROM {$this->table} 
                WHERE location_id = :location_id AND payment_mode_id = :payment_mode_id";
        $params = [
            'location_id' => $locationId,
            'payment_mode_id' => $paymentModeId
        ];

        if ($accountNumber) {
            $sql .= " AND account_number = :account_number";
            $params['account_number'] = $accountNumber;
        }

        if ($excludeId) {
            $sql .= " AND id != :excludeId";
            $params['excludeId'] = $excludeId;
        }

        $result = Database::fetch($sql, $params);
        return $result['count'] > 0;
    }

    /**
     * Create new account
     */
    public function createAccount(array $data): int
    {
        $sql = "INSERT INTO {$this->table} (location_type_id, location_id, payment_mode_id, account_name, account_number, balance, status) 
                VALUES (:location_type_id, :location_id, :payment_mode_id, :account_name, :account_number, :balance, :status)";
        
        Database::query($sql, [
            'location_type_id' => $data['location_type_id'],
            'location_id' => $data['location_id'],
            'payment_mode_id' => $data['payment_mode_id'],
            'account_name' => $data['account_name'],
            'account_number' => $data['account_number'] ?: null,
            'balance' => $data['balance'] ?? 0.00,
            'status' => $data['status'] ?? 'active'
        ]);

        return Database::getInstance()->lastInsertId();
    }

    /**
     * Update account
     */
    public function updateAccount(int $id, array $data): bool
    {
        $sql = "UPDATE {$this->table} SET 
                location_type_id = :location_type_id,
                location_id = :location_id,
                payment_mode_id = :payment_mode_id,
                account_name = :account_name,
                account_number = :account_number,
                balance = :balance,
                status = :status
                WHERE id = :id";
        
        Database::query($sql, [
            'id' => $id,
            'location_type_id' => $data['location_type_id'],
            'location_id' => $data['location_id'],
            'payment_mode_id' => $data['payment_mode_id'],
            'account_name' => $data['account_name'],
            'account_number' => $data['account_number'] ?: null,
            'balance' => $data['balance'] ?? 0.00,
            'status' => $data['status'] ?? 'active'
        ]);

        return true;
    }

    /**
     * Delete account
     */
    public function deleteAccount(int $id): bool
    {
        $sql = "DELETE FROM {$this->table} WHERE id = :id";
        Database::query($sql, ['id' => $id]);
        return true;
    }

    /**
     * Toggle status
     */
    public function toggleStatus(int $id): bool
    {
        $sql = "UPDATE {$this->table} SET status = CASE WHEN status = 'active' THEN 'inactive' ELSE 'active' END WHERE id = :id";
        Database::query($sql, ['id' => $id]);
        return true;
    }

    /**
     * Get accounts by location
     */
    public function getByLocation(int $locationId): array
    {
        $sql = "SELECT a.*, pm.name as payment_mode_name
                FROM {$this->table} a
                LEFT JOIN payment_modes pm ON a.payment_mode_id = pm.id
                WHERE a.location_id = :location_id AND a.status = 'active'
                ORDER BY a.account_name ASC";
        return Database::fetchAll($sql, ['location_id' => $locationId]);
    }

    /**
     * Update balance
     */
    public function updateBalance(int $id, float $amount, string $operation = 'add'): bool
    {
        if ($operation === 'add') {
            $sql = "UPDATE {$this->table} SET balance = balance + :amount WHERE id = :id";
        } else {
            $sql = "UPDATE {$this->table} SET balance = balance - :amount WHERE id = :id";
        }
        
        Database::query($sql, ['id' => $id, 'amount' => $amount]);
        return true;
    }
}