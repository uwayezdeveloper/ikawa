<?php
namespace Models;

require_once __DIR__ . '/../config/Database.php';

use Config\Database;
use PDO;
use PDOException;

class ProductionTransfer
{
    private $conn;

    public function __construct()
    {
        $db = new Database();
        $this->conn = $db->getConnection();
    }

    public function generateReferenceNo(): string
    {
        $prefix = 'TRF';
        $date = date('Ymd');
        $random = strtoupper(substr(uniqid(), -4));
        return $prefix . $date . $random;
    }

    public function getAvailableStock(int $loc_id)
    {
        try {
            $sql = "
                SELECT 
                    ss.stock_summary_id,
                    ss.assignment_id,
                    ss.sup_id,
                    ss.total_quantity,
                    ctu.type_id,
                    ctu.unit_id,
                    ct.type_name,
                    u.unit_name,
                    s.full_name as supplier_name,
                    s.type as supplier_type
                FROM tbl_stock_summary ss
                INNER JOIN tbl_category_type_units ctu ON ss.assignment_id = ctu.assignment_id
                INNER JOIN tbl_category_types ct ON ctu.type_id = ct.type_id
                INNER JOIN tbl_units u ON ctu.unit_id = u.unit_id
                INNER JOIN tbl_suppliers s ON ss.sup_id = s.sup_id
                WHERE ss.loc_id = :loc_id AND ss.total_quantity > 0
                ORDER BY ct.type_name, u.unit_name, s.full_name
            ";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([':loc_id' => $loc_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error fetching available stock: " . $e->getMessage());
            return false;
        }
    }

    public function createTransferBatch(array $data): array
    {
        try {
            $this->conn->beginTransaction();

            $reference_no = $this->generateReferenceNo();
            $total_items = count($data['items']);
            $total_quantity = 0;

            // Calculate total quantity
            foreach ($data['items'] as $item) {
                $total_quantity += floatval($item['quantity']);
            }

            // Insert tracking record
            $trackingSql = "
                INSERT INTO tbl_transfer_tracking 
                (reference_no, from_loc_id, to_loc_id, transfer_date, total_items, total_quantity, notes, user_id, status) 
                VALUES 
                (:reference_no, :from_loc_id, :to_loc_id, :transfer_date, :total_items, :total_quantity, :notes, :user_id, 'pending')
            ";
            $trackingStmt = $this->conn->prepare($trackingSql);
            $trackingStmt->execute([
                ':reference_no' => $reference_no,
                ':from_loc_id' => $data['from_loc_id'],
                ':to_loc_id' => $data['to_loc_id'],
                ':transfer_date' => $data['transfer_date'],
                ':total_items' => $total_items,
                ':total_quantity' => $total_quantity,
                ':notes' => $data['notes'],
                ':user_id' => $data['user_id']
            ]);

            $tracking_id = $this->conn->lastInsertId();

            // Insert each item and deduct from stock
            foreach ($data['items'] as $item) {
                $assignment_id = $item['assignment_id'];
                $sup_id = $item['sup_id'];
                $quantity = floatval($item['quantity']);

                // Check available stock
                $checkSql = "
                    SELECT total_quantity FROM tbl_stock_summary 
                    WHERE loc_id = :loc_id AND assignment_id = :assignment_id AND sup_id = :sup_id
                ";
                $checkStmt = $this->conn->prepare($checkSql);
                $checkStmt->execute([
                    ':loc_id' => $data['from_loc_id'],
                    ':assignment_id' => $assignment_id,
                    ':sup_id' => $sup_id
                ]);
                $stock = $checkStmt->fetch(PDO::FETCH_ASSOC);

                if (!$stock || $stock['total_quantity'] < $quantity) {
                    $this->conn->rollBack();
                    return ['success' => false, 'message' => 'Insufficient stock for one or more items'];
                }

                // Insert transfer detail with assignment_id
                $detailSql = "
                    INSERT INTO tbl_transfer_details 
                    (tracking_id, assignment_id, sup_id, quantity) 
                    VALUES 
                    (:tracking_id, :assignment_id, :sup_id, :quantity)
                ";
                $detailStmt = $this->conn->prepare($detailSql);
                $detailStmt->execute([
                    ':tracking_id' => $tracking_id,
                    ':assignment_id' => $assignment_id,
                    ':sup_id' => $sup_id,
                    ':quantity' => $quantity
                ]);

                // Deduct from stock summary
                $deductSql = "
                    UPDATE tbl_stock_summary 
                    SET total_quantity = total_quantity - :quantity, updated_at = CURRENT_TIMESTAMP
                    WHERE loc_id = :loc_id AND assignment_id = :assignment_id AND sup_id = :sup_id
                ";
                $deductStmt = $this->conn->prepare($deductSql);
                $deductStmt->execute([
                    ':quantity' => $quantity,
                    ':loc_id' => $data['from_loc_id'],
                    ':assignment_id' => $assignment_id,
                    ':sup_id' => $sup_id
                ]);
            }

            $this->conn->commit();
            return ['success' => true, 'reference_no' => $reference_no, 'tracking_id' => $tracking_id];
        } catch (PDOException $e) {
            $this->conn->rollBack();
            error_log("Error creating transfer batch: " . $e->getMessage());
            return ['success' => false, 'message' => 'Database error occurred: ' . $e->getMessage()];
        }
    }

    public function getTransfersByLocation(int $loc_id)
    {
        try {
            $sql = "
                SELECT 
                    tt.*,
                    fl.location_name as from_location,
                    tl.location_name as to_location,
                    u.username as created_by,
                    ct.type_name,
                    un.unit_name,
                    s.full_name as supplier_name,
                    s.type as supplier_type
                FROM tbl_transfer_tracking tt
                LEFT JOIN tbl_location fl ON tt.from_loc_id = fl.loc_id
                LEFT JOIN tbl_location tl ON tt.to_loc_id = tl.loc_id
                LEFT JOIN tbl_users u ON tt.user_id = u.user_id
                LEFT JOIN tbl_transfer_details td ON tt.tracking_id = td.tracking_id
                LEFT JOIN tbl_category_type_units ctu ON td.assignment_id = ctu.assignment_id
                LEFT JOIN tbl_category_types ct ON ctu.type_id = ct.type_id
                LEFT JOIN tbl_units un ON ctu.unit_id = un.unit_id
                LEFT JOIN tbl_suppliers s ON td.sup_id = s.sup_id
                WHERE tt.from_loc_id = :loc_id
                GROUP BY tt.tracking_id
                ORDER BY tt.created_at DESC
            ";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([':loc_id' => $loc_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error fetching transfers: " . $e->getMessage());
            return false;
        }
    }

    public function getTransferDetails(int $tracking_id)
    {
        try {
            $sql = "
                SELECT 
                    td.*,
                    ctu.type_id,
                    ctu.unit_id,
                    ct.type_name,
                    u.unit_name,
                    s.full_name as supplier_name,
                    s.type as supplier_type
                FROM tbl_transfer_details td
                LEFT JOIN tbl_category_type_units ctu ON td.assignment_id = ctu.assignment_id
                LEFT JOIN tbl_category_types ct ON ctu.type_id = ct.type_id
                LEFT JOIN tbl_units u ON ctu.unit_id = u.unit_id
                LEFT JOIN tbl_suppliers s ON td.sup_id = s.sup_id
                WHERE td.tracking_id = :tracking_id
                ORDER BY ct.type_name, u.unit_name
            ";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([':tracking_id' => $tracking_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error fetching transfer details: " . $e->getMessage());
            return false;
        }
    }

    public function updateTransferStatus(int $tracking_id, string $status): bool
    {
        try {
            $sql = "UPDATE tbl_transfer_tracking SET status = :status, updated_at = CURRENT_TIMESTAMP WHERE tracking_id = :tracking_id";
            $stmt = $this->conn->prepare($sql);
            return $stmt->execute([':status' => $status, ':tracking_id' => $tracking_id]);
        } catch (PDOException $e) {
            error_log("Error updating transfer status: " . $e->getMessage());
            return false;
        }
    }

    public function approveTransfer(int $tracking_id): array
    {
        try {
            // Verify transfer exists and is pending
            $checkSql = "SELECT status FROM tbl_transfer_tracking WHERE tracking_id = :tracking_id";
            $checkStmt = $this->conn->prepare($checkSql);
            $checkStmt->execute([':tracking_id' => $tracking_id]);
            $transfer = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if (!$transfer) {
                return ['success' => false, 'message' => 'Transfer not found'];
            }

            if ($transfer['status'] !== 'pending') {
                return ['success' => false, 'message' => 'Only pending transfers can be approved'];
            }

            // Update status to in_transit
            $success = $this->updateTransferStatus($tracking_id, 'in_transit');

            if ($success) {
                return ['success' => true, 'message' => 'Transfer approved and marked as in transit'];
            } else {
                return ['success' => false, 'message' => 'Failed to approve transfer'];
            }
        } catch (PDOException $e) {
            error_log("Error approving transfer: " . $e->getMessage());
            return ['success' => false, 'message' => 'Database error occurred'];
        }
    }

    public function returnTransfer(array $data): array
    {
        try {
            $this->conn->beginTransaction();

            $tracking_id = $data['tracking_id'];
            
            // Verify transfer exists and is not already returned
            $checkSql = "SELECT status, from_loc_id FROM tbl_transfer_tracking WHERE tracking_id = :tracking_id";
            $checkStmt = $this->conn->prepare($checkSql);
            $checkStmt->execute([':tracking_id' => $tracking_id]);
            $transfer = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if (!$transfer) {
                $this->conn->rollBack();
                return ['success' => false, 'message' => 'Transfer not found'];
            }

            if ($transfer['status'] === 'returned') {
                $this->conn->rollBack();
                return ['success' => false, 'message' => 'Transfer already returned'];
            }

            $total_returned = 0;

            // Process each return item
            foreach ($data['items'] as $item) {
                $detail_id = $item['detail_id'];
                $return_qty = floatval($item['return_quantity']);
                $total_returned += $return_qty;

                // Get original transfer detail
                $detailSql = "SELECT * FROM tbl_transfer_details WHERE transfer_detail_id = :transfer_detail_id";
                $detailStmt = $this->conn->prepare($detailSql);
                $detailStmt->execute([':transfer_detail_id' => $detail_id]);
                $detail = $detailStmt->fetch(PDO::FETCH_ASSOC);

                if (!$detail || $return_qty > $detail['quantity']) {
                    $this->conn->rollBack();
                    return ['success' => false, 'message' => 'Invalid return quantity'];
                }

                // Check if stock summary record exists using assignment_id
                $checkStockSql = "
                    SELECT stock_summary_id, total_quantity 
                    FROM tbl_stock_summary 
                    WHERE loc_id = :loc_id AND assignment_id = :assignment_id AND sup_id = :sup_id
                ";
                $checkStockStmt = $this->conn->prepare($checkStockSql);
                $checkStockStmt->execute([
                    ':loc_id' => $transfer['from_loc_id'],
                    ':assignment_id' => $detail['assignment_id'],
                    ':sup_id' => $detail['sup_id']
                ]);
                $existingStock = $checkStockStmt->fetch(PDO::FETCH_ASSOC);

                if ($existingStock) {
                    // Update existing stock
                    $updateStockSql = "
                        UPDATE tbl_stock_summary 
                        SET total_quantity = total_quantity + :quantity,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE stock_summary_id = :stock_summary_id
                    ";
                    $updateStockStmt = $this->conn->prepare($updateStockSql);
                    $updateStockStmt->execute([
                        ':quantity' => $return_qty,
                        ':stock_summary_id' => $existingStock['stock_summary_id']
                    ]);
                } else {
                    // Insert new stock summary record
                    $insertStockSql = "
                        INSERT INTO tbl_stock_summary 
                        (loc_id, assignment_id, sup_id, total_quantity, created_at, updated_at)
                        VALUES 
                        (:loc_id, :assignment_id, :sup_id, :quantity, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    ";
                    $insertStockStmt = $this->conn->prepare($insertStockSql);
                    $insertStockStmt->execute([
                        ':loc_id' => $transfer['from_loc_id'],
                        ':assignment_id' => $detail['assignment_id'],
                        ':sup_id' => $detail['sup_id'],
                        ':quantity' => $return_qty
                    ]);
                }

                // Mark detail as returned or update return quantity
                $updateDetailSql = "
                    UPDATE tbl_transfer_details 
                    SET returned_quantity = :return_qty, updated_at = CURRENT_TIMESTAMP 
                    WHERE transfer_detail_id = :transfer_detail_id
                ";
                $updateDetailStmt = $this->conn->prepare($updateDetailSql);
                $updateDetailStmt->execute([
                    ':return_qty' => $return_qty,
                    ':transfer_detail_id' => $detail_id
                ]);
            }

            // Update tracking record
            $updateTrackingSql = "
                UPDATE tbl_transfer_tracking 
                SET status = 'returned', 
                    return_date = :return_date,
                    return_reason = :return_reason,
                    returned_quantity = :returned_quantity,
                    updated_at = CURRENT_TIMESTAMP 
                WHERE tracking_id = :tracking_id
            ";
            $updateTrackingStmt = $this->conn->prepare($updateTrackingSql);
            $updateTrackingStmt->execute([
                ':return_date' => $data['return_date'],
                ':return_reason' => $data['return_reason'],
                ':returned_quantity' => $total_returned,
                ':tracking_id' => $tracking_id
            ]);

            $this->conn->commit();
            return ['success' => true, 'message' => 'Transfer returned successfully'];
        } catch (PDOException $e) {
            $this->conn->rollBack();
            error_log("Error returning transfer: " . $e->getMessage());
            return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
        }
    }

    public function receiveProduction(array $data): array
    {
        try {
            $this->conn->beginTransaction();

            $tracking_id = $data['tracking_id'];
            $sup_id = $data['sup_id'];
            $loc_id = $data['loc_id'];
            $user_id = $data['user_id'];
            $receive_date = $data['receive_date'];
            $notes = $data['notes'] ?? '';

            // Verify transfer exists and is in_transit
            $checkSql = "SELECT status, from_loc_id, total_quantity, received_quantity FROM tbl_transfer_tracking WHERE tracking_id = :tracking_id";
            $checkStmt = $this->conn->prepare($checkSql);
            $checkStmt->execute([':tracking_id' => $tracking_id]);
            $transfer = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if (!$transfer) {
                $this->conn->rollBack();
                return ['success' => false, 'message' => 'Transfer not found'];
            }

            if ($transfer['status'] !== 'in_transit') {
                $this->conn->rollBack();
                return ['success' => false, 'message' => 'Only in-transit transfers can receive production'];
            }

            // Calculate total quantity being received
            $total_received = 0;
            foreach ($data['items'] as $item) {
                $total_received += floatval($item['quantity']);
            }

            // Get already received quantity (if any partial receipts were allowed)
            $already_received = floatval($transfer['received_quantity'] ?? 0);
            $transferred_quantity = floatval($transfer['total_quantity']);
            $available_to_receive = $transferred_quantity - $already_received;

            // Validate that total received doesn't exceed what was transferred
            if ($total_received > $available_to_receive) {
                $this->conn->rollBack();
                return [
                    'success' => false, 
                    'message' => "Cannot receive more than transferred. Transferred: {$transferred_quantity}, Already received: {$already_received}, Available: {$available_to_receive}, Trying to receive: {$total_received}"
                ];
            }

            // Process each received item
            foreach ($data['items'] as $item) {
                $type_id = $item['type_id'];
                $unit_id = $item['unit_id'];
                $quantity = floatval($item['quantity']);

                // Get assignment_id from type_id and unit_id
                $assignmentSql = "
                    SELECT assignment_id 
                    FROM tbl_category_type_units 
                    WHERE type_id = :type_id AND unit_id = :unit_id AND status = 'active'
                    LIMIT 1
                ";
                $assignmentStmt = $this->conn->prepare($assignmentSql);
                $assignmentStmt->execute([
                    ':type_id' => $type_id,
                    ':unit_id' => $unit_id
                ]);
                $assignmentResult = $assignmentStmt->fetch(PDO::FETCH_ASSOC);

                if (!$assignmentResult) {
                    $this->conn->rollBack();
                    return ['success' => false, 'message' => 'Invalid type/unit combination'];
                }

                $assignment_id = $assignmentResult['assignment_id'];

                // Insert into production receipt table
                $receiptSql = "
                    INSERT INTO tbl_production_receipts 
                    (tracking_id, assignment_id, sup_id, quantity, receive_date, notes, loc_id, user_id, created_at)
                    VALUES 
                    (:tracking_id, :assignment_id, :sup_id, :quantity, :receive_date, :notes, :loc_id, :user_id, CURRENT_TIMESTAMP)
                ";
                $receiptStmt = $this->conn->prepare($receiptSql);
                $receiptStmt->execute([
                    ':tracking_id' => $tracking_id,
                    ':assignment_id' => $assignment_id,
                    ':sup_id' => $sup_id,
                    ':quantity' => $quantity,
                    ':receive_date' => $receive_date,
                    ':notes' => $notes,
                    ':loc_id' => $loc_id,
                    ':user_id' => $user_id
                ]);

                // Update or insert into stock summary using assignment_id
                $checkStockSql = "
                    SELECT stock_summary_id, total_quantity 
                    FROM tbl_stock_summary 
                    WHERE loc_id = :loc_id AND assignment_id = :assignment_id AND sup_id = :sup_id
                ";
                $checkStockStmt = $this->conn->prepare($checkStockSql);
                $checkStockStmt->execute([
                    ':loc_id' => $loc_id,
                    ':assignment_id' => $assignment_id,
                    ':sup_id' => $sup_id
                ]);
                $existingStock = $checkStockStmt->fetch(PDO::FETCH_ASSOC);

                if ($existingStock) {
                    // Update existing stock
                    $updateStockSql = "
                        UPDATE tbl_stock_summary 
                        SET total_quantity = total_quantity + :quantity,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE stock_summary_id = :stock_summary_id
                    ";
                    $updateStockStmt = $this->conn->prepare($updateStockSql);
                    $updateStockStmt->execute([
                        ':quantity' => $quantity,
                        ':stock_summary_id' => $existingStock['stock_summary_id']
                    ]);
                } else {
                    // Insert new stock summary record
                    $insertStockSql = "
                        INSERT INTO tbl_stock_summary 
                        (loc_id, assignment_id, sup_id, total_quantity, created_at, updated_at)
                        VALUES 
                        (:loc_id, :assignment_id, :sup_id, :quantity, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    ";
                    $insertStockStmt = $this->conn->prepare($insertStockSql);
                    $insertStockStmt->execute([
                        ':loc_id' => $loc_id,
                        ':assignment_id' => $assignment_id,
                        ':sup_id' => $sup_id,
                        ':quantity' => $quantity
                    ]);
                }
            }

            // Update transfer tracking status to completed
            $updateTrackingSql = "
                UPDATE tbl_transfer_tracking 
                SET status = 'completed', 
                    received_date = :receive_date,
                    received_quantity = :received_quantity,
                    updated_at = CURRENT_TIMESTAMP 
                WHERE tracking_id = :tracking_id
            ";
            $updateTrackingStmt = $this->conn->prepare($updateTrackingSql);
            $updateTrackingStmt->execute([
                ':receive_date' => $receive_date,
                ':received_quantity' => $already_received + $total_received,
                ':tracking_id' => $tracking_id
            ]);

            $this->conn->commit();
            return ['success' => true, 'message' => 'Production received successfully'];
        } catch (PDOException $e) {
            $this->conn->rollBack();
            error_log("Error receiving production: " . $e->getMessage());
            return ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
        }
    }

    // Add method to get transfer info for validation
    public function getTransferInfo(int $tracking_id)
    {
        try {
            $sql = "
                SELECT 
                    tt.tracking_id,
                    tt.reference_no,
                    tt.total_quantity,
                    tt.received_quantity,
                    tt.status,
                    (tt.total_quantity - COALESCE(tt.received_quantity, 0)) as available_to_receive
                FROM tbl_transfer_tracking tt
                WHERE tt.tracking_id = :tracking_id
            ";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([':tracking_id' => $tracking_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error fetching transfer info: " . $e->getMessage());
            return false;
        }
    }
}
