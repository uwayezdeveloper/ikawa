<script>
$(document).ready(function () {

    let TransferTable;
    let allStockData = []; // Store all stock data
    let receiveRowCounter = 0;
    let categoriesData = [];
    let maxReceiveQuantity = 0; // Store max quantity that can be received
    
    // Initialize DataTable
    function initTransferTable() {
        if ($.fn.DataTable.isDataTable('#transfer-history-table')) {
            $('#transfer-history-table').DataTable().destroy();
        }
        TransferTable = $('#transfer-history-table').DataTable({
            pageLength: 10
        });
    }

    initTransferTable();

    // Load transfer history (called after actions only)
    function loadTransferHistory() {
        $.getJSON('<?= App::baseUrl() ?>/_ikawa/transfers/get-all', function (res) {
            if (!res.success) return;

            if ($.fn.DataTable.isDataTable('#transfer-history-table')) {
                $('#transfer-history-table').DataTable().destroy();
            }
            
            $('#transferHistoryData').empty();

            if (res.data && res.data.length > 0) {
                $.each(res.data, function (index, record) {
                    var statusClass = record.status === 'completed' ? 'label-success' : 
                                    (record.status === 'returned' ? 'label-danger' :
                                    (record.status === 'in_transit' ? 'label-info' :
                                    (record.status === 'pending' ? 'label-warning' : 'label-default')));
                    
                    var approveBtn = record.status === 'pending' ? 
                        '<button class="btn btn-sm btn-success approve-transfer-btn" data-id="' + record.tracking_id + '" data-ref="' + record.reference_no + '" title="Approve Transfer">' +
                            '<i class="fa fa-check"></i>' +
                        '</button> ' : '';
                    
                    var receiveBtn = record.status === 'in_transit' ? 
                        '<button class="btn btn-sm btn-primary receive-production-btn" data-id="' + record.tracking_id + '" data-ref="' + record.reference_no + '" title="Receive from Production">' +
                            '<i class="fa fa-download"></i>' +
                        '</button> ' : '';
                    
                    var returnBtn = (record.status !== 'returned' && record.status !== 'pending' && record.status !== 'completed') ? 
                        '<button class="btn btn-sm btn-warning return-transfer-btn" data-id="' + record.tracking_id + '" data-ref="' + record.reference_no + '" title="Return Transfer">' +
                            '<i class="fa fa-undo"></i>' +
                        '</button> ' : '';
                    
                    var statusLabel = record.status.charAt(0).toUpperCase() + record.status.slice(1).replace('_', ' ');
                    var supplierDisplay = (record.supplier_name || 'N/A') + ' / ' + (record.supplier_type || 'N/A');
                    
                    var row = '<tr>' +
                        '<td>' + (index + 1) + '</td>' +
                        '<td><strong>' + record.reference_no + '</strong></td>' +
                        '<td>' + supplierDisplay + '</td>' +
                        '<td>' + (record.type_name || 'N/A') + '</td>' +
                        '<td>' + record.total_quantity + '</td>' +
                        '<td>' + new Date(record.transfer_date).toLocaleDateString() + '</td>' +
                        '<td><span class="label ' + statusClass + '">' + statusLabel + '</span></td>' +
                        '<td>' +
                            approveBtn +
                            receiveBtn +
                            returnBtn +
                            '<button class="btn btn-sm btn-info view-details-btn" data-id="' + record.tracking_id + '" data-ref="' + record.reference_no + '">' +
                                '<i class="fa fa-eye"></i>' +
                            '</button>' +
                        '</td>' +
                    '</tr>';
                    
                    $('#transferHistoryData').append(row);
                });
            } else {
                $('#transferHistoryData').html('<tr><td colspan="8" class="text-center">No transfers found</td></tr>');
            }

            TransferTable = $('#transfer-history-table').DataTable({
                pageLength: 10
            });
        });
    }

    // Load available stock filtered by supplier
    function loadAvailableStock(supplierId = null) {
        var tbody = document.getElementById('availableStockBody');
        
        if (!tbody) {
            console.log('availableStockBody not found in DOM');
            return;
        }
        
        if (!supplierId) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">Please select a supplier to view available stock</td></tr>';
            return;
        }
        
        console.log('Loading available stock for supplier:', supplierId);
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">Loading...</td></tr>';
        
        var apiUrl = '<?= App::baseUrl() ?>/_ikawa/transfers/get-available-stock';
        console.log('Calling:', apiUrl);
        
        $.ajax({
            url: apiUrl,
            method: 'GET',
            dataType: 'json',
            cache: false,
            success: function(res) {
                console.log('Response:', res);
                
                var tbody = document.getElementById('availableStockBody');
                if (!tbody) {
                    console.log('availableStockBody disappeared from DOM');
                    return;
                }
                
                if (res.success && res.data && res.data.length > 0) {
                    // Filter by selected supplier
                    var filteredData = res.data.filter(function(item) {
                        return item.sup_id == supplierId;
                    });
                    
                    if (filteredData.length > 0) {
                        var html = '';
                        for (var i = 0; i < filteredData.length; i++) {
                            var item = filteredData[i];
                            var stockJson = encodeURIComponent(JSON.stringify(item));
                            var displayName = (item.type_name || 'N/A') + ' / ' + (item.unit_name || 'N/A');
                            
                            html += '<tr data-stock-encoded="' + stockJson + '">' +
                                '<td><input type="checkbox" class="stock-checkbox"></td>' +
                                '<td>' + displayName + '</td>' +
                                '<td>' + item.total_quantity + '</td>' +
                                '<td><input type="number" step="0.01" class="form-control transfer-qty" max="' + item.total_quantity + '" placeholder="0"></td>' +
                            '</tr>';
                        }
                        tbody.innerHTML = html;
                        console.log('Added', filteredData.length, 'rows for supplier');
                    } else {
                        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-warning">No stock available for this supplier</td></tr>';
                    }
                } else {
                    tbody.innerHTML = '<tr><td colspan="4" class="text-center">No stock available</td></tr>';
                }
            },
            error: function(xhr, status, error) {
                console.log('AJAX Error:', status, error, xhr.responseText);
                var tbody = document.getElementById('availableStockBody');
                if (tbody) {
                    tbody.innerHTML = '<tr><td colspan="4" class="text-center text-danger">Error: ' + error + '</td></tr>';
                }
            }
        });
    }

    // Load categories for receive modal
    function loadCategories() {
        return $.ajax({
            url: '<?= App::baseUrl() ?>/_ikawa/categories/get-active-categories',
            method: 'GET',
            dataType: 'json',
            success: function(res) {
                if (res.success && res.data) {
                    categoriesData = res.data;
                }
            }
        });
    }

    // Generate category options HTML for receive modal
    function getCategoryOptionsForReceive() {
        let options = '<option value="">Select Category</option>';
        $.each(categoriesData, function(index, cat) {
            options += '<option value="' + cat.category_id + '">' + cat.category_name + '</option>';
        });
        return options;
    }

    // Add row to receive items table
    function addReceiveRow() {
        receiveRowCounter++;
        const rowHtml = `
            <tr id="receiveRow_${receiveRowCounter}" data-row="${receiveRowCounter}">
                <td>
                    <select class="form-control receive-category-select" data-row="${receiveRowCounter}" name="receive_category_${receiveRowCounter}">
                        ${getCategoryOptionsForReceive()}
                    </select>
                </td>
                <td>
                    <select class="form-control receive-type-unit-select" data-row="${receiveRowCounter}" name="receive_type_unit_${receiveRowCounter}" disabled>
                        <option value="">Select Type / Unity</option>
                    </select>
                </td>
                <td>
                    <input type="number" step="0.01" class="form-control receive-quantity" data-row="${receiveRowCounter}" name="receive_qty_${receiveRowCounter}" placeholder="0">
                </td>
                <td>
                    <button type="button" class="btn btn-danger btn-sm remove-receive-row-btn" data-row="${receiveRowCounter}">
                        <i class="fa fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
        $('#receiveItemsBody').append(rowHtml);
        updateReceiveTotalDisplay();
    }

    // Calculate and display total receive quantity
    function calculateReceiveTotal() {
        let total = 0;
        $('#receiveItemsBody tr').each(function() {
            var rowId = $(this).data('row');
            var qty = parseFloat($('input[name="receive_qty_' + rowId + '"]').val()) || 0;
            total += qty;
        });
        return total;
    }

    // Update receive total display
    function updateReceiveTotalDisplay() {
        var total = calculateReceiveTotal();
        var remaining = maxReceiveQuantity - total;
        
        $('#receive_total_entering').text(total.toFixed(2));
        $('#receive_remaining').text(remaining.toFixed(2));
        
        if (total > maxReceiveQuantity) {
            $('#receive_total_entering').addClass('text-danger').removeClass('text-success');
            $('#receive_remaining').addClass('text-danger').removeClass('text-success');
        } else {
            $('#receive_total_entering').removeClass('text-danger').addClass('text-success');
            $('#receive_remaining').removeClass('text-danger').addClass('text-success');
        }
    }

    // Update total when quantity changes
    $(document).on('input change', '.receive-quantity', function() {
        updateReceiveTotalDisplay();
    });

    // Load category type/unity when category changes in receive modal
    $(document).on('change', '.receive-category-select', function() {
        const rowId = $(this).data('row');
        const categoryId = $(this).val();
        const typeUnitSelect = $('select[name="receive_type_unit_' + rowId + '"]');

        typeUnitSelect.html('<option value="">Select Type / Unity</option>').prop('disabled', true);

        if (!categoryId) return;

        typeUnitSelect.html('<option value="">Loading...</option>');

        $.ajax({
            url: '<?= App::baseUrl() ?>/_ikawa/category-type-units/get-type-unity-by-category/' + categoryId,
            method: 'GET',
            dataType: 'json',
            success: function(res) {
                let options = '<option value="">Select Type / Unity</option>';
                if (res.success && res.data && res.data.length > 0) {
                    $.each(res.data, function(index, item) {
                        const value = JSON.stringify({type_id: item.type_id, unit_id: item.unit_id});
                        options += '<option value=\'' + value + '\'>' + item.type_unit_name + '</option>';
                    });
                    typeUnitSelect.html(options).prop('disabled', false);
                } else {
                    typeUnitSelect.html('<option value="">No types available</option>').prop('disabled', true);
                }
            },
            error: function() {
                typeUnitSelect.html('<option value="">Error loading</option>').prop('disabled', true);
            }
        });
    });

    // Remove row from receive items table
    $(document).on('click', '.remove-receive-row-btn', function() {
        const rowId = $(this).data('row');
        $('#receiveRow_' + rowId).remove();
        
        if ($('#receiveItemsBody tr').length === 0) {
            addReceiveRow();
        }
        updateReceiveTotalDisplay();
    });

    // Add row button click
    $(document).on('click', '#addReceiveRowBtn', function() {
        addReceiveRow();
    });

    // Load stock when transfer modal opens
    $(document).on('show.bs.modal', '#transferModal', function() {
        console.log('Transfer modal opening...');
        
        $('#transfer_date').val('<?= date('Y-m-d') ?>');
        $('#transfer_notes').val('');
        $('#availableStockBody').html('<tr><td colspan="4" class="text-center text-muted">Please select a supplier to view available stock</td></tr>');
        
        // Reset and reinitialize chosen select
        $('#transfer_supplier_select').val('').trigger('chosen:updated');
        
        // Destroy and reinitialize chosen if needed
        setTimeout(function() {
            if ($('#transfer_supplier_select').data('chosen')) {
                $('#transfer_supplier_select').chosen('destroy');
            }
            $('#transfer_supplier_select').chosen({
                width: '100%',
                disable_search_threshold: 10
            });
        }, 100);
    });

    // Handle supplier selection change
    $(document).on('change', '#transfer_supplier_select', function() {
        var supplierId = $(this).val();
        console.log('Supplier selected:', supplierId);
        
        if (supplierId) {
            loadAvailableStock(supplierId);
        } else {
            $('#availableStockBody').html('<tr><td colspan="4" class="text-center text-muted">Please select a supplier to view available stock</td></tr>');
        }
    });

    // Select all checkbox
    $(document).on('change', '#selectAllStock', function() {
        $('.stock-checkbox').prop('checked', $(this).is(':checked'));
    });

    // Save transfer
    $(document).on('click', '#saveTransferBtn', function() {
        var btn = this;
        var transfer_date = $('#transfer_date').val();
        var notes = $('#transfer_notes').val();
        var supplier_id = $('#transfer_supplier_select').val();

        if (!supplier_id) {
            showToast('Please select a supplier!', 'error');
            return;
        }

        if (!transfer_date) {
            showToast('Please select transfer date!', 'error');
            return;
        }

        var items = [];
        var hasError = false;
        
        $('#availableStockBody tr').each(function() {
            var checkbox = $(this).find('.stock-checkbox');
            var qtyInput = $(this).find('.transfer-qty');
            
            if (checkbox.is(':checked')) {
                var qty = parseFloat(qtyInput.val()) || 0;
                var maxQty = parseFloat(qtyInput.attr('max')) || 0;
                
                if (qty > 0 && qty <= maxQty) {
                    var encodedData = $(this).attr('data-stock-encoded');
                    if (encodedData) {
                        try {
                            var stockData = JSON.parse(decodeURIComponent(encodedData));
                            // Use assignment_id instead of type_id
                            items.push({
                                assignment_id: stockData.assignment_id,
                                sup_id: stockData.sup_id,
                                quantity: qty
                            });
                        } catch(e) {
                            console.log('Parse error:', e);
                        }
                    }
                } else if (qty > maxQty) {
                    showToast('Transfer quantity cannot exceed available quantity!', 'error');
                    hasError = true;
                    return false;
                }
            }
        });

        if (hasError) return;

        if (items.length === 0) {
            showToast('Please select items and enter valid quantities to transfer!', 'error');
            return;
        }

        setButtonLoading(btn, true);

        $.ajax({
            url: '<?= App::baseUrl() ?>/_ikawa/transfers/create-multiple',
            method: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify({
                transfer_date: transfer_date,
                notes: notes,
                items: items
            }),
            success: function(response) {
                if (response.success) {
                    showToast(response.message + ' Ref: ' + response.data.reference_no, 'success');
                    $('#transferModal').modal('hide');
                    loadTransferHistory();
                } else {
                    showToast(response.message, 'error');
                }
            },
            error: function(xhr) {
                var msg = 'Error creating transfer';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    msg = xhr.responseJSON.message;
                }
                showToast(msg, 'error');
            },
            complete: function() {
                setButtonLoading(btn, false);
            }
        });
    });

    // View transfer details
    $(document).on('click', '.view-details-btn', function() {
        var tracking_id = $(this).data('id');
        var ref_no = $(this).data('ref');
        
        $('#detailRefNo').text(ref_no);
        $('#transferDetailsBody').html('<tr><td colspan="5" class="text-center">Loading...</td></tr>');
        $('#viewDetailsModal').modal('show');

        $.ajax({
            url: '<?= App::baseUrl() ?>/_ikawa/transfers/get-details/' + tracking_id,
            method: 'GET',
            dataType: 'json',
            success: function(res) {
                var tbody = document.getElementById('transferDetailsBody');
                if (!tbody) return;
                
                if (res.success && res.data && res.data.length > 0) {
                    var html = '';
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];
                        var supplierDisplay = (item.supplier_name || 'N/A') + ' / ' + (item.supplier_type || 'N/A');
                        html += '<tr>' +
                            '<td>' + (i + 1) + '</td>' +
                            '<td>' + (item.type_name || 'N/A') + '</td>' +
                            '<td>' + (item.unit_name || 'N/A') + '</td>' +
                            '<td>' + supplierDisplay + '</td>' +
                            '<td>' + item.quantity + '</td>' +
                        '</tr>';
                    }
                    tbody.innerHTML = html;
                } else {
                    tbody.innerHTML = '<tr><td colspan="5" class="text-center">No details found</td></tr>';
                }
            },
            error: function() {
                var tbody = document.getElementById('transferDetailsBody');
                if (tbody) {
                    tbody.innerHTML = '<tr><td colspan="5" class="text-center text-danger">Error loading details</td></tr>';
                }
            }
        });
    });

    // Approve transfer
    $(document).on('click', '.approve-transfer-btn', function() {
        var btn = this;
        var tracking_id = $(this).data('id');
        var ref_no = $(this).data('ref');
        
        swal({   
            title: "Approve Transfer?",   
            text: "Are you sure you want to approve transfer " + ref_no + "?",   
            type: "warning",   
            showCancelButton: true,   
            confirmButtonText: "Yes, approve it!",
            cancelButtonText: "No, cancel!"
        }).then(function(isConfirm){
            if (isConfirm) {
                setButtonLoading(btn, true);

                $.ajax({
                    url: '<?= App::baseUrl() ?>/_ikawa/transfers/approve',
                    method: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    data: JSON.stringify({ tracking_id: tracking_id }),
                    success: function(response) {
                        if (response.success) {
                            swal("Approved!", response.message, "success");
                            loadTransferHistory();
                        } else {
                            swal("Error!", response.message, "error");
                        }
                    },
                    error: function(xhr) {
                        var msg = 'Error approving transfer';
                        try {
                            var response = JSON.parse(xhr.responseText);
                            if (response.message) {
                                msg = response.message;
                            }
                        } catch(e) {
                            msg = xhr.responseText || 'Unknown error';
                        }
                        swal("Error!", msg, "error");
                    },
                    complete: function() {
                        setButtonLoading(btn, false);
                    }
                });
            }
        });
    });

    // Return transfer button click
    $(document).on('click', '.return-transfer-btn', function() {
        var tracking_id = $(this).data('id');
        var ref_no = $(this).data('ref');
        
        $('#returnRefNo').text(ref_no);
        $('#returnItemsBody').html('<tr><td colspan="5" class="text-center">Loading...</td></tr>');
        $('#return_date').val('<?= date('Y-m-d') ?>');
        $('#return_reason').val('');
        $('#returnTransferModal').modal('show');

        $.ajax({
            url: '<?= App::baseUrl() ?>/_ikawa/transfers/get-details/' + tracking_id,
            method: 'GET',
            dataType: 'json',
            success: function(res) {
                var tbody = document.getElementById('returnItemsBody');
                if (!tbody) return;
                
                if (res.success && res.data && res.data.length > 0) {
                    var html = '';
                    for (var i = 0; i < res.data.length; i++) {
                        var item = res.data[i];
                        var supplierDisplay = (item.supplier_name || 'N/A') + ' / ' + (item.supplier_type || 'N/A');
                        
                        html += '<tr data-detail-id="' + item.transfer_detail_id + '">' +
                            '<td><input type="checkbox" class="return-checkbox"></td>' +
                            '<td>' + (item.type_name || 'N/A') + '</td>' +
                            '<td>' + supplierDisplay + '</td>' +
                            '<td>' + item.quantity + '</td>' +
                            '<td><input type="number" step="0.01" class="form-control return-qty" max="' + item.quantity + '" placeholder="0" style="width:100px;"></td>' +
                        '</tr>';
                    }
                    tbody.innerHTML = html;
                    
                    // Store tracking_id for later use
                    $('#returnTransferModal').data('tracking-id', tracking_id);
                } else {
                    tbody.innerHTML = '<tr><td colspan="5" class="text-center">No details found</td></tr>';
                }
            }
        });
    });

    // Select all return items
    $(document).on('change', '#selectAllReturn', function() {
        $('.return-checkbox').prop('checked', $(this).is(':checked'));
    });

    // Save return transfer
    $(document).on('click', '#saveReturnBtn', function() {
        var btn = this;
        var tracking_id = $('#returnTransferModal').data('tracking-id');
        var return_date = $('#return_date').val();
        var return_reason = $('#return_reason').val().trim();

        console.log('Return transfer - tracking_id:', tracking_id);

        if (!tracking_id) {
            showToast('Invalid tracking ID!', 'error');
            return;
        }

        if (!return_date) {
            showToast('Please select return date!', 'error');
            return;
        }

        if (!return_reason) {
            showToast('Please enter return reason!', 'error');
            return;
        }

        var items = [];
        var hasError = false;
        
        $('#returnItemsBody tr').each(function() {
            var checkbox = $(this).find('.return-checkbox');
            var qtyInput = $(this).find('.return-qty');
            
            if (checkbox.is(':checked')) {
                var qty = parseFloat(qtyInput.val()) || 0;
                var maxQty = parseFloat(qtyInput.attr('max')) || 0;
                var detail_id = $(this).data('detail-id');
                
                if (qty > 0 && qty <= maxQty) {
                    items.push({
                        detail_id: detail_id,
                        return_quantity: qty
                    });
                } else if (qty > maxQty) {
                    showToast('Return quantity cannot exceed transferred quantity!', 'error');
                    hasError = true;
                    return false;
                }
            }
        });

        if (hasError) return;

        if (items.length === 0) {
            showToast('Please select items and enter valid quantities to return!', 'error');
            return;
        }

        var payload = {
            tracking_id: tracking_id,
            return_date: return_date,
            return_reason: return_reason,
            items: items
        };

        console.log('Sending return payload:', payload);

        setButtonLoading(btn, true);

        $.ajax({
            url: '<?= App::baseUrl() ?>/_ikawa/transfers/return',
            method: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify(payload),
            success: function(response) {
                console.log('Return response:', response);
                if (response.success) {
                    showToast(response.message, 'success');
                    $('#returnTransferModal').modal('hide');
                    loadTransferHistory();
                } else {
                    showToast(response.message, 'error');
                }
            },
            error: function(xhr, status, error) {
                console.log('Return error:', xhr.responseText);
                var msg = 'Error returning transfer';
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.message) {
                        msg = response.message;
                    }
                } catch(e) {
                    msg = xhr.responseText || error;
                }
                showToast(msg, 'error');
            },
            complete: function() {
                setButtonLoading(btn, false);
            }
        });
    });

    // Receive from Production button click
    $(document).on('click', '.receive-production-btn', function() {
        var tracking_id = $(this).data('id');
        var ref_no = $(this).data('ref');
        
        $('#receiveRefNo').text(ref_no);
        $('#receive_date').val('<?= date('Y-m-d') ?>');
        $('#receive_notes').val('');
        $('#receiveItemsBody').empty();
        receiveRowCounter = 0;
        maxReceiveQuantity = 0;
        
        $('#receiveProductionModal').data('tracking-id', tracking_id);
        
        // Load transfer details to show info
        $.ajax({
            url: '<?= App::baseUrl() ?>/_ikawa/transfers/get-details/' + tracking_id,
            method: 'GET',
            dataType: 'json',
            success: function(res) {
                if (res.success && res.data && res.data.length > 0) {
                    var item = res.data[0];
                    var supplierDisplay = (item.supplier_name || 'N/A') + ' / ' + (item.supplier_type || 'N/A');
                    var typeUnitDisplay = (item.type_name || 'N/A') + ' / ' + (item.unit_name || 'N/A');
                    
                    $('#receive_supplier').val(supplierDisplay);
                    $('#receive_original_type').val(typeUnitDisplay);
                    
                    // Calculate total qty from transfer details
                    var totalQty = 0;
                    for (var i = 0; i < res.data.length; i++) {
                        totalQty += parseFloat(res.data[i].quantity) || 0;
                    }
                    $('#receive_total_qty').val(totalQty);
                    
                    // Store supplier id for later
                    $('#receiveProductionModal').data('sup-id', item.sup_id);
                }
            }
        });

        // Get transfer info to know max receivable quantity
        $.ajax({
            url: '<?= App::baseUrl() ?>/_ikawa/transfers/get-info/' + tracking_id,
            method: 'GET',
            dataType: 'json',
            success: function(res) {
                if (res.success && res.data) {
                    maxReceiveQuantity = parseFloat(res.data.available_to_receive) || 0;
                    $('#receive_max_qty').text(maxReceiveQuantity.toFixed(2));
                    updateReceiveTotalDisplay();
                }
            },
            error: function() {
                // Fallback: use total_qty from transfer details
                var totalQty = parseFloat($('#receive_total_qty').val()) || 0;
                maxReceiveQuantity = totalQty;
                $('#receive_max_qty').text(maxReceiveQuantity.toFixed(2));
            }
        });
        
        // Load categories and add first row
        loadCategories().done(function() {
            addReceiveRow();
        });
        
        $('#receiveProductionModal').modal('show');
    });

    // Save received items - with validation
    $(document).on('click', '#saveReceiveBtn', function() {
        var btn = this;
        var tracking_id = $('#receiveProductionModal').data('tracking-id');
        var sup_id = $('#receiveProductionModal').data('sup-id');
        var receive_date = $('#receive_date').val();
        var notes = $('#receive_notes').val();

        if (!tracking_id) {
            showToast('Invalid tracking ID!', 'error');
            return;
        }

        if (!receive_date) {
            showToast('Please select receive date!', 'error');
            return;
        }

        var items = [];
        var hasError = false;
        var totalReceiving = 0;

        $('#receiveItemsBody tr').each(function() {
            var rowId = $(this).data('row');
            var typeUnitValue = $('select[name="receive_type_unit_' + rowId + '"]').val();
            var quantity = parseFloat($('input[name="receive_qty_' + rowId + '"]').val()) || 0;

            if (!typeUnitValue || quantity <= 0) {
                hasError = true;
                $(this).addClass('danger');
                return;
            } else {
                $(this).removeClass('danger');
            }

            totalReceiving += quantity;

            try {
                var parsed = JSON.parse(typeUnitValue);
                items.push({
                    type_id: parsed.type_id,
                    unit_id: parsed.unit_id,
                    quantity: quantity
                });
            } catch(e) {
                hasError = true;
            }
        });

        if (hasError || items.length === 0) {
            showToast('Please fill all required fields in each row!', 'error');
            return;
        }

        // Validate total quantity doesn't exceed max
        if (totalReceiving > maxReceiveQuantity) {
            showToast('Total receive quantity (' + totalReceiving.toFixed(2) + ') exceeds available quantity (' + maxReceiveQuantity.toFixed(2) + ')!', 'error');
            return;
        }

        var payload = {
            tracking_id: tracking_id,
            sup_id: sup_id,
            receive_date: receive_date,
            notes: notes,
            items: items
        };

        console.log('Sending receive payload:', payload);

        setButtonLoading(btn, true);

        $.ajax({
            url: '<?= App::baseUrl() ?>/_ikawa/transfers/receive-production',
            method: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify(payload),
            success: function(response) {
                console.log('Receive response:', response);
                if (response.success) {
                    showToast(response.message, 'success');
                    $('#receiveProductionModal').modal('hide');
                    loadTransferHistory();
                } else {
                    showToast(response.message, 'error');
                }
            },
            error: function(xhr, status, error) {
                console.log('Receive error:', xhr.responseText);
                var msg = 'Error receiving production';
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.message) {
                        msg = response.message;
                    }
                } catch(e) {
                    msg = xhr.responseText || error;
                }
                showToast(msg, 'error');
            },
            complete: function() {
                setButtonLoading(btn, false);
            }
        });
    });
});
</script>
