
<!-- Start Status area -->
<div class = 'notika-status-area'>
<div class = 'container'>
<div class = 'row'>
<div class = 'col-lg-3 col-md-6 col-sm-6 col-xs-12'>
<div class = 'wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30'>
<div class = 'website-traffic-ctn'>
<h2><span class="counter">
    
    <?php
    $loc_id=$_SESSION['loc_id'];
    $apiUrl = App::baseUrl() . '/_ikawa/users/get-all-users?loc_id='.$loc_id;
    $json = fetchApiData($apiUrl);
    $result = json_decode($json, true);
    $users=0;
    if ($result['success'] && !empty($result['data'])) {
        
        foreach ($result['data'] as $index => $user) {
            $users++;
            
        }
    echo $users;
    }
    else{
        
        echo 0;
    }
 ?>
</span></h2>
<p>Active Users</p>
</div>
<div class = 'sparkline-bar-stats1'>9, 4, 8, 6, 5, 6, 4, 8, 3, 5, 9, 5</div>
</div>
</div>
<div class = 'col-lg-3 col-md-6 col-sm-6 col-xs-12'>
<div class = 'wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30'>
<div class = 'website-traffic-ctn'>
<h2><span class = 'counter'>
     <?php
        // Use location-filtered endpoint
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $userLocationId = isset($_SESSION['loc_id']) ? $_SESSION['loc_id'] : '';
        
        if ($userLocationId) {
            $apiUrl = App::baseUrl() . '/_ikawa/accounts/get-allbylocation?st_id=' . $userLocationId;
            $json = fetchApiData($apiUrl);
           
            $result = json_decode($json, true);
        } else {
            $result = ['success' => false, 'data' => []];
        }
        
        $Accountsbalance=0;
        
        if ($result && $result['success'] && !empty($result['data'])) {
            foreach ($result['data'] as $index => $record) {
                $Accountsbalance+=$record['balance'];
            }
        echo number_format($Accountsbalance);
        }
        else{
            echo 0;
        }
                ?>
    
 </span> RWF</h2>
<p>Total Accounts Balance</p>
</div>
<div class = 'sparkline-bar-stats2'>1, 4, 8, 3, 5, 6, 4, 8, 3, 3, 9, 5</div>
</div>
</div>
<div class = 'col-lg-3 col-md-6 col-sm-6 col-xs-12'>
<div class = 'wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30 dk-res-mg-t-30'>
<div class = 'website-traffic-ctn'>
<h2><span class = 'counter'>
    <?php
    $apiUrl = App::baseUrl() . '/_ikawa/expense-consume/get-all';
    $json =fetchApiData($apiUrl);
    $result = json_decode($json, true);
    $totalExpenses=0;
    if ($result && $result['success'] && !empty($result['data'])) {
        foreach ($result['data'] as $index => $record) {
            $totalExpenses+=$record['amount'];
        }
    echo number_format($totalExpenses);
    }
    else{
        echo 0;
    }
    ?>
    
</span> RWF</h2>
<p>Total Expenses</p>
</div>
<div class = 'sparkline-bar-stats3'>4, 2, 8, 2, 5, 6, 3, 8, 3, 5, 9, 5</div>
</div>
</div>
<!-- Total Suppliers -->
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
    <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30 dk-res-mg-t-30">
        <div class="website-traffic-ctn">
            <h2><span class="counter">
                <?php
                $apiUrl = App::baseUrl() . '/_ikawa/inventory/getsuppliers';
                $json = fetchApiData($apiUrl);
                $result = json_decode($json, true);
                $supplierCount = 0;
                
                if ($result && $result['success'] && !empty($result['data'])) {
                    $supplierCount = count($result['data']);
                }
                echo number_format($supplierCount);
                ?>
            </span></h2>
            <p>Total Suppliers</p>
            <div class="traffic-icon">
                <i class="notika-icon notika-ship"></i>
            </div>
        </div>
        <div class="sparkline-bar-stats4" id="suppliers-sparkline">4, 2, 8, 2, 5, 6, 3, 8, 3, 5, 9, 5</div>
    </div>
</div>
</div>
</div>
</div>
<br><br>
<!-- Start Email Statistic area-->
<div class = 'notika-email-post-area'>
<div class = 'container'>
<div class = 'row'>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
    <div class="email-statis-inner notika-shadow">
        <div class="email-ctn-round">
            <div class="email-rdn-hd">
                <h2>Products Statistics</h2>
                <?php
                $apiUrl = App::baseUrl() . '/_ikawa/category-type-units/get-all-assignments';
                $json = fetchApiData($apiUrl);
                $result = json_decode($json, true);
                
                $categories = [];
                $totalProducts = 0;
                
                if ($result['success'] && !empty($result['data'])) {
                    // Group by category and count
                    foreach ($result['data'] as $item) {
                        $category = $item['category_name'];
                        if (!isset($categories[$category])) {
                            $categories[$category] = 0;
                        }
                        $categories[$category]++;
                        $totalProducts++;
                    }
                    
                    // Get top 3 categories
                    arsort($categories);
                    $topCategories = array_slice($categories, 0, 3, true);
                    
                    // Calculate percentages
                    $percentages = [];
                    foreach ($topCategories as $category => $count) {
                        $percentages[$category] = round(($count / $totalProducts) * 100);
                    }
                }
                ?>
            </div>
            
            <?php if (!empty($categories)): ?>
            <div class="email-statis-wrap">
                <div class="email-round-nock">
                    <input type="text" class="knob" 
                           value="<?php echo $percentages[key($topCategories)] ?? 0; ?>" 
                           data-rel="<?php echo $percentages[key($topCategories)] ?? 0; ?>" 
                           data-linecap="round" 
                           data-width="130" 
                           data-bgcolor="#E4E4E4" 
                           data-fgcolor="#00c292" 
                           data-thickness=".10" 
                           data-readonly="true">
                </div>
                <div class="email-ctn-nock">
                    <p style="font-weight: 600; margin-bottom: 5px;"><?php echo key($topCategories) ?? 'No Category'; ?></p>
                    <p style="font-size: 12px; color: #666;">Top Product Category</p>
                </div>
            </div>
            
            <div class="email-round-gp">
                <?php 
                $i = 0;
                $colors = ['#FF9800', '#2196F3', '#9C27B0'];
                foreach ($topCategories as $category => $count): 
                    if ($i >= 3) break;
                ?>
                <div class="email-round-pro">
                    <div class="email-signle-gp">
                        <input type="text" class="knob" 
                               value="<?php echo $percentages[$category] ?? 0; ?>" 
                               data-rel="<?php echo $percentages[$category] ?? 0; ?>" 
                               data-linecap="round" 
                               data-width="90" 
                               data-bgcolor="#E4E4E4" 
                               data-fgcolor="<?php echo $colors[$i]; ?>" 
                               data-thickness=".10" 
                               data-readonly="true" disabled>
                    </div>
                    <div class="email-ctn-nock">
                        <p style="font-size: 13px; font-weight: 500;"><?php echo $category; ?></p>
                        <p style="font-size: 11px; color: #888;"><?php echo $count; ?> products</p>
                    </div>
                </div>
                <?php $i++; endforeach; ?>
            </div>
            
            
            <?php else: ?>
            <div class="text-center py-4">
                <i class="notika-icon notika-form" style="font-size: 40px; color: #ccc;"></i>
                <p style="margin-top: 10px; color: #888;">No product data available</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class = 'col-lg-8 col-md-8 col-sm-12 col-xs-12'>
<div class = 'recent-items-wp notika-shadow sm-res-mg-t-30'>
<div class = 'rc-it-ltd'>
<div class = 'recent-items-ctn'>
<div class = 'recent-items-title'>
<h2>Accounts Info</h2>
</div>
</div>
<div class = 'recent-items-inn'>
<table class="table table-striped">
    <thead>
        <tr>
            <th>#</th>
            <th>Account Name</th>
            <th>Reference Number</th>
            <th>Payment Mode</th>
            <th>Location</th>
            <th>Balance</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody id="accountsdata">
        <?php
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $userLocationId = isset($_SESSION['loc_id']) ? $_SESSION['loc_id'] : '';
        
        if ($userLocationId) {
            $apiUrl = App::baseUrl() . '/_ikawa/accounts/get-allbylocation?st_id=' . $userLocationId;
            $json = fetchApiData($apiUrl);
            $result = json_decode($json, true);
        } else {
            $result = ['success' => false, 'data' => []];
        }
        
        if ($result && $result['success'] && !empty($result['data'])) {
            // Limit to 3 accounts
            $limitedData = array_slice($result['data'], 0, 3);
            
            foreach ($limitedData as $index => $record) {
                // Format reference number with ***
                $refNum = $record['acc_reference_num'] ?? '';
                if (strlen($refNum) > 8) {
                    $formattedRef = substr($refNum, 0, 4) . '***' . substr($refNum, -4);
                } else {
                    $formattedRef = $refNum;
                }
                
                $statusBadge = $record['status'] == 1 ? 
                    '<span class="badge badge-success">Active</span>' : 
                    '<span class="badge badge-warning">Onhold</span>';
        ?>
        <tr>
            <td><?php echo $index + 1 ?></td>
            <td><?php echo htmlspecialchars($record['acc_name']); ?></td>
            <td><?php echo htmlspecialchars($formattedRef); ?></td>
            <td><?php echo htmlspecialchars($record['Mode_names'] ?? 'N/A'); ?></td>
            <td><?php echo htmlspecialchars($record['location_name'] ?? 'N/A'); ?></td>
            <td><?php echo number_format($record['balance']); ?> RWF</td>
            <td><?php echo $statusBadge; ?></td>
        </tr>
        <?php 
            }
        } else {
        ?>
        <tr>
            <td colspan="7" class="text-center">No accounts found</td>
        </tr>
        <?php } ?>
    </tbody>
</table>
</div>
<div id = 'recent-items-chart' class = 'flot-chart-items flot-chart vt-ct-it tb-rc-it-res'></div>
</div>
</div>
</div>
</div>
</div>
</div>